const reportId = new URLSearchParams(window.location.search).get("id");
const form = document.getElementById("edit-report-form");
const loadPanel = document.getElementById("load-panel");
const loadStatus = document.getElementById("load-status");
const statusElement = document.getElementById("edit-status");
const saveButton = document.getElementById("save-button");
const headElement = document.getElementById("actuals-table-head");
const bodyElement = document.getElementById("actuals-table-body");

const importMembershipButton =
  document.getElementById("import-membership-button");

const membershipImportStatus =
  document.getElementById("membership-import-status");

const membershipSection =
  document.getElementById("membership-section");

const membershipBreakdowns =
  document.getElementById("membership-breakdowns");

const playingMembershipBreakdownBody =
  document.getElementById("playing-membership-breakdown-body");

const nonPlayingMembershipBreakdownBody =
  document.getElementById("non-playing-membership-breakdown-body");

let report = null;
let hasUnsavedChanges = false;
let membershipImportInProgress = false;

const defaultMembershipNarrative =
  "At the start of each subscription year, we assume that playing " +
  "membership will reduce by approximately 8%. This is a pattern " +
  "we have seen consistently over a number of years and is built " +
  "into all of our budgets. Our aim is to recruit enough new " +
  "playing members during the year to recover that reduction and " +
  "return playing membership to the level recorded at the start " +
  "of the subscription year.";

function monthDate(month) {
  return new Date(month.year, month.month - 1, 1);
}

function monthLabel(month) {
  return new Intl.DateTimeFormat("en-GB", {
    month: "short",
    year: "2-digit"
  }).format(monthDate(month));
}

function formatDate(value) {
  if (!value) {
    return "—";
  }

  return new Intl.DateTimeFormat("en-GB", {
    day: "numeric",
    month: "long",
    year: "numeric"
  }).format(new Date(`${value}T00:00:00`));
}

function formatDateTime(value) {
  if (!value) {
    return "—";
  }

  const date = new Date(value);

  if (Number.isNaN(date.getTime())) {
    return "—";
  }

  return new Intl.DateTimeFormat("en-GB", {
    day: "numeric",
    month: "long",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit"
  }).format(date);
}

function currency(value) {
  if (value === null || value === undefined) {
    return "—";
  }

  return new Intl.NumberFormat("en-GB", {
    style: "currency",
    currency: "GBP",
    maximumFractionDigits: 0
  }).format(value);
}

function integer(value) {
  if (value === null || value === undefined) {
    return "—";
  }

  return Number(value).toLocaleString("en-GB", {
    maximumFractionDigits: 0
  });
}

function setStatus(message, kind = "") {
  statusElement.textContent = message;
  statusElement.className =
    `status-message${kind ? ` is-${kind}` : ""}`;
}

function setMembershipStatus(message, kind = "") {
  membershipImportStatus.textContent = message;
  membershipImportStatus.className =
    `status-message${kind ? ` is-${kind}` : ""}`;
}

function setText(id, value) {
  document.getElementById(id).textContent = value ?? "";
}

function actualInput(lineKey, year, month) {
  return document.querySelector(
    `[data-line="${lineKey}"]` +
    `[data-year="${year}"]` +
    `[data-month="${month}"]`
  );
}

function readActual(input) {
  return input.value.trim() === ""
    ? null
    : Number(input.value);
}

function updateTotals() {
  report.financialLines.forEach(line => {
    const inputs = line.months.map(month =>
      actualInput(
        line.key,
        month.year,
        month.month
      )
    );

    const values = inputs.map(readActual);

    const actualTotal = values.every(value => value !== null)
      ? values.reduce((total, value) => total + value, 0)
      : null;

    const totalElement = document.querySelector(
      `[data-actual-total="${line.key}"]`
    );

    totalElement.textContent = actualTotal === null
      ? "Actual —"
      : `Actual ${currency(actualTotal)}`;
  });

  updateNetProfitRow();
}

function updateNetProfitRow() {
  const monthKeys = report.financialLines[0].months.map(
    month => `${month.year}-${month.month}`
  );

  monthKeys.forEach(key => {
    const [year, month] = key
      .split("-")
      .map(Number);

    let budget = 0;
    let actual = 0;
    let complete = true;

    report.financialLines.forEach(line => {
      const value = line.months.find(
        item =>
          item.year === year &&
          item.month === month
      );

      const sign = line.type === "Expense"
        ? -1
        : 1;

      budget += value.budget * sign;

      const inputValue = readActual(
        actualInput(
          line.key,
          year,
          month
        )
      );

      if (inputValue === null) {
        complete = false;
      } else {
        actual += inputValue * sign;
      }
    });

    document.querySelector(
      `[data-net-budget="${key}"]`
    ).textContent = `Budget ${currency(budget)}`;

    document.querySelector(
      `[data-net-actual="${key}"]`
    ).textContent = complete
      ? `Actual ${currency(actual)}`
      : "Actual —";
  });

  let annualBudget = 0;
  let annualActual = 0;
  let annualComplete = true;

  report.financialLines.forEach(line => {
    const sign = line.type === "Expense"
      ? -1
      : 1;

    annualBudget += line.months.reduce(
      (total, month) =>
        total + month.budget,
      0
    ) * sign;

    line.months.forEach(month => {
      const value = readActual(
        actualInput(
          line.key,
          month.year,
          month.month
        )
      );

      if (value === null) {
        annualComplete = false;
      } else {
        annualActual += value * sign;
      }
    });
  });

  document.getElementById(
    "net-annual-budget"
  ).textContent =
    `Budget ${currency(annualBudget)}`;

  document.getElementById(
    "net-annual-actual"
  ).textContent = annualComplete
    ? `Actual ${currency(annualActual)}`
    : "Actual —";
}

function renderTable() {
  const months = report.financialLines[0].months;

  const headerRow =
    document.createElement("tr");

  [
    "Financial line",
    ...months.map(monthLabel),
    "Annual"
  ].forEach(label => {
    const th = document.createElement("th");

    th.scope = "col";
    th.textContent = label;

    headerRow.append(th);
  });

  headElement.replaceChildren(headerRow);
  bodyElement.replaceChildren();

  report.financialLines
    .sort(
      (left, right) =>
        left.displayOrder - right.displayOrder
    )
    .forEach(line => {
      const row = document.createElement("tr");

      const labelCell =
        document.createElement("th");

      labelCell.scope = "row";

      labelCell.innerHTML =
        `<strong>${line.label}</strong>` +
        `<span>${line.type}</span>`;

      row.append(labelCell);

      line.months.forEach(month => {
        const cell =
          document.createElement("td");

        cell.className =
          "actual-budget-cell";

        const budget =
          document.createElement("span");

        budget.className = "budget-value";

        budget.textContent =
          `Budget ${currency(month.budget)}`;

        const wrapper =
          document.createElement("label");

        wrapper.className =
          "currency-input currency-input--actual";

        const prefix =
          document.createElement("span");

        prefix.textContent = "£";

        const input =
          document.createElement("input");

        input.type = "number";
        input.step = "0.01";
        input.value = month.actual ?? "";
        input.placeholder = "Actual";
        input.dataset.line = line.key;
        input.dataset.year = String(month.year);
        input.dataset.month = String(month.month);

        input.setAttribute(
          "aria-label",
          `${line.label}, ${monthLabel(month)} actual`
        );

        input.addEventListener(
          "input",
          updateTotals
        );

        wrapper.append(prefix, input);
        cell.append(budget, wrapper);
        row.append(cell);
      });

      const annualCell =
        document.createElement("td");

      annualCell.className =
        "actual-budget-cell annual-total";

      const annualBudget =
        line.months.reduce(
          (total, month) =>
            total + month.budget,
          0
        );

      annualCell.innerHTML =
        `<span>Budget ${currency(annualBudget)}</span>` +
        `<strong data-actual-total="${line.key}">` +
        `Actual —` +
        `</strong>`;

      row.append(annualCell);
      bodyElement.append(row);
    });

  const netRow =
    document.createElement("tr");

  netRow.className = "net-profit-row";

  const netLabel =
    document.createElement("th");

  netLabel.scope = "row";

  netLabel.innerHTML =
    "<strong>Net Profit Before Taxation</strong>" +
    "<span>Calculated</span>";

  netRow.append(netLabel);

  months.forEach(month => {
    const key =
      `${month.year}-${month.month}`;

    const cell =
      document.createElement("td");

    cell.className =
      "actual-budget-cell";

    cell.innerHTML =
      `<span data-net-budget="${key}"></span>` +
      `<strong data-net-actual="${key}"></strong>`;

    netRow.append(cell);
  });

  const annualNet =
    document.createElement("td");

  annualNet.className =
    "actual-budget-cell annual-total";

  annualNet.innerHTML =
    '<span id="net-annual-budget"></span>' +
    '<strong id="net-annual-actual"></strong>';

  netRow.append(annualNet);
  bodyElement.append(netRow);

  updateTotals();
}

function renderBreakdownTable(
  body,
  items
) {
  body.replaceChildren();

  items
    .filter(
      item =>
        Number(item.value) > 0
    )
    .sort((left, right) => {
      const valueDifference =
        Number(right.value) -
        Number(left.value);

      return valueDifference !== 0
        ? valueDifference
        : left.label.localeCompare(
            right.label,
            "en-GB"
          );
    })
    .forEach(item => {
      const row =
        document.createElement("tr");

      const labelCell =
        document.createElement("th");

      const valueCell =
        document.createElement("td");

      labelCell.scope = "row";
      labelCell.textContent = item.label;
      valueCell.textContent =
        integer(item.value);

      row.append(
        labelCell,
        valueCell
      );

      body.append(row);
    });
}

function buildMembershipGroupBreakdowns(
  snapshot
) {
  const categoryGroups =
    snapshot?.categoryGroupBreakdown ?? {};

  const playingGroupNames = new Set([
    "7 Day Membership",
    "6 Day Membership",
    "5 Day Membership",
    "Intermediate Membership"
  ]);

  const playing = [];
  const nonPlaying = [];

  Object.entries(categoryGroups).forEach(
    ([label, value]) => {
      const item = {
        label,
        value: Number(value)
      };

      if (playingGroupNames.has(label)) {
        playing.push(item);
      } else {
        nonPlaying.push(item);
      }
    }
  );

  return {
    playing,
    nonPlaying
  };
}

function updateImportButtonState() {
  const snapshot = report?.membershipSnapshot;

  importMembershipButton.textContent = snapshot
    ? "Refresh membership data"
    : "Import membership data";

  /*
   * Do not disable the button merely because the form is dirty.
   * The click handler needs to run so it can explain that the
   * report must be saved first.
   */
  importMembershipButton.disabled =
    report === null ||
    membershipImportInProgress;

  if (membershipImportInProgress) {
    importMembershipButton.textContent =
      "Importing membership data…";

    importMembershipButton.title = "";
    return;
  }

  importMembershipButton.title = hasUnsavedChanges
    ? "Save the report before importing membership data."
    : "";
}

function renderMembershipSnapshot() {
  const snapshot =
    report?.membershipSnapshot ?? null;

  const figuresCorrectAsAt =
    document
      .getElementById(
        "figures-correct-as-at"
      )
      .value ||
    report?.figuresCorrectAsAt;

  membershipSection.dataset.status =
    "missing";

  if (!snapshot) {
    setText(
      "membership-snapshot-status",
      "Not imported"
    );

    setText(
      "membership-data-as-at",
      "—"
    );

    setText(
      "membership-imported-at",
      "—"
    );

    setText(
      "membership-source-generated-at",
      "—"
    );

    setText(
      "membership-playing-members",
      "—"
    );

    setText(
      "membership-non-playing-members",
      "—"
    );

    setText(
      "membership-total-members",
      "—"
    );

    membershipBreakdowns.hidden = true;

    setMembershipStatus(
      "No membership snapshot has been imported for this report."
    );

    updateImportButtonState();
    return;
  }

  const snapshotIsCurrent =
    snapshot.dataAsAt ===
    figuresCorrectAsAt;

  membershipSection.dataset.status =
    snapshotIsCurrent
      ? "current"
      : "stale";

  setText(
    "membership-snapshot-status",
    snapshotIsCurrent
      ? "Current"
      : "Needs refreshing"
  );

  setText(
    "membership-data-as-at",
    formatDate(snapshot.dataAsAt)
  );

  setText(
    "membership-imported-at",
    formatDateTime(
      snapshot.importedAtUtc
    )
  );

  setText(
    "membership-source-generated-at",
    formatDateTime(
      snapshot.sourceGeneratedAtUtc
    )
  );

  setText(
    "membership-playing-members",
    integer(snapshot.playingMembers)
  );

  setText(
    "membership-non-playing-members",
    integer(snapshot.nonPlayingMembers)
  );

  setText(
    "membership-total-members",
    integer(
      snapshot.totalMembers ??
      Number(
        snapshot.playingMembers ?? 0
      ) +
      Number(
        snapshot.nonPlayingMembers ?? 0
      )
    )
  );

  const breakdowns =
    buildMembershipGroupBreakdowns(
      snapshot
    );

  renderBreakdownTable(
    playingMembershipBreakdownBody,
    breakdowns.playing
  );

  renderBreakdownTable(
    nonPlayingMembershipBreakdownBody,
    breakdowns.nonPlaying
  );

  membershipBreakdowns.hidden =
    breakdowns.playing.length === 0 &&
    breakdowns.nonPlaying.length === 0;

  if (snapshotIsCurrent) {
    setMembershipStatus(
      `Membership data is current to ` +
      `${formatDate(snapshot.dataAsAt)}.`,
      "success"
    );
  } else {
    setMembershipStatus(
      `Membership data is dated ` +
      `${formatDate(snapshot.dataAsAt)}, ` +
      `but the financial figures are dated ` +
      `${formatDate(figuresCorrectAsAt)}. ` +
      `Save the report, then refresh the membership data.`,
      "error"
    );
  }

  updateImportButtonState();
}

function markFormDirty() {
  if (!report) {
    return;
  }

  hasUnsavedChanges = true;

  updateImportButtonState();

  if (report.membershipSnapshot) {
    setMembershipStatus(
      "Save the report before refreshing the membership data."
    );
  }
}

function populateForm() {
  document.title =
    `Edit ${report.title}`;

  document.getElementById(
    "page-title"
  ).textContent = report.title;

  document.getElementById(
    "title"
  ).value = report.title;

  document.getElementById(
    "reporting-period-start"
  ).value = report.reportingPeriodStart;

  document.getElementById(
    "reporting-period-end"
  ).value = report.reportingPeriodEnd;

  document.getElementById(
    "figures-correct-as-at"
  ).value = report.figuresCorrectAsAt;

  document.getElementById(
    "financial-year-label"
  ).textContent =
    `${formatDate(report.financialYearStart)} – ` +
    `${formatDate(report.financialYearEnd)}`;

  document.getElementById(
    "version-label"
  ).textContent =
    `Version ${report.version}`;

  document.getElementById(
    "view-report-link"
  ).href =
    `/?id=${encodeURIComponent(report.id)}`;

  document.getElementById(
    "financial-commentary"
  ).value =
    (
      report.presentation
        ?.financialCommentary ??
      []
    ).join("\n\n");

  const membershipNarrative =
    report.presentation
      ?.membershipNarrative;

  document.getElementById(
    "membership-narrative"
  ).value =
    typeof membershipNarrative === "string" &&
    membershipNarrative.trim().length > 0
      ? membershipNarrative
      : defaultMembershipNarrative;

  document.getElementById(
    "year-end-forecast-net-profit-before-taxation"
  ).value =
    report
      .yearEndForecastNetProfitBeforeTaxation ??
    "";

  renderTable();

  hasUnsavedChanges = false;

  renderMembershipSnapshot();
  updateImportButtonState();
}

async function loadReport() {
  if (!reportId) {
    loadStatus.textContent =
      "No report ID was supplied.";

    loadStatus.classList.add(
      "is-error"
    );

    return;
  }

  try {
    const response = await fetch(
      `/api/kpi-reports/` +
      `${encodeURIComponent(reportId)}`,
      {
        cache: "no-store"
      }
    );

    if (!response.ok) {
      throw new Error(
        response.status === 404
          ? "The KPI report was not found."
          : `The server returned ${response.status}.`
      );
    }

    report = await response.json();

    populateForm();

    loadPanel.hidden = true;
    form.hidden = false;
  } catch (error) {
    loadStatus.textContent =
      error.message;

    loadStatus.classList.add(
      "is-error"
    );
  }
}

form.addEventListener(
  "input",
  markFormDirty
);

form.addEventListener(
  "change",
  markFormDirty
);

form.addEventListener(
  "submit",
  async event => {
    event.preventDefault();

    setStatus("Saving report…");

    saveButton.disabled = true;

    report.title =
      document
        .getElementById("title")
        .value
        .trim();

    report.reportingPeriodStart =
      document
        .getElementById(
          "reporting-period-start"
        )
        .value;

    report.reportingPeriodEnd =
      document
        .getElementById(
          "reporting-period-end"
        )
        .value;

    report.figuresCorrectAsAt =
      document
        .getElementById(
          "figures-correct-as-at"
        )
        .value;

    report.presentation ??= {};

    report.presentation.membershipNarrative =
      document
        .getElementById(
          "membership-narrative"
        )
        .value
        .trim();

    report.presentation.financialCommentary =
      document
        .getElementById(
          "financial-commentary"
        )
        .value
        .trim()
        .split(/\r?\n\s*\r?\n+/)
        .map(
          paragraph =>
            paragraph.trim()
        )
        .filter(
          paragraph =>
            paragraph.length > 0
        );

    report.financialLines.forEach(
      line => {
        line.months.forEach(
          month => {
            month.actual =
              readActual(
                actualInput(
                  line.key,
                  month.year,
                  month.month
                )
              );
          }
        );
      }
    );

    const yearEndForecastValue =
      document
        .getElementById(
          "year-end-forecast-net-profit-before-taxation"
        )
        .value
        .trim();

    report
      .yearEndForecastNetProfitBeforeTaxation =
      yearEndForecastValue === ""
        ? null
        : Number(
            yearEndForecastValue
          );

    try {
      const response = await fetch(
        `/api/kpi-reports/` +
        `${encodeURIComponent(report.id)}`,
        {
          method: "PUT",
          headers: {
            "Content-Type":
              "application/json"
          },
          body: JSON.stringify(report)
        }
      );

      if (!response.ok) {
        const problem =
          await response
            .json()
            .catch(() => null);

        const messages =
          Object.entries(
            problem?.errors ?? {}
          )
            .flatMap(
              ([key, values]) =>
                values.map(
                  value =>
                    `${key}: ${value}`
                )
            );

        throw new Error(
          messages.join(" ") ||
          problem?.detail ||
          problem?.message ||
          `The server returned ${response.status}.`
        );
      }

      report = await response.json();

      hasUnsavedChanges = false;

      document.getElementById(
        "version-label"
      ).textContent =
        `Version ${report.version}`;

      renderMembershipSnapshot();
      updateImportButtonState();

      setStatus(
        "Saved. The graph and financial table now use these values.",
        "success"
      );
    } catch (error) {
      setStatus(
        error.message,
        "error"
      );
    } finally {
      saveButton.disabled = false;
    }
  }
);

importMembershipButton.addEventListener(
  "click",
  async () => {
    if (
      !report ||
      hasUnsavedChanges
    ) {
      setMembershipStatus(
        "Save the report before importing membership data.",
        "error"
      );

      return;
    }

    membershipImportInProgress = true;

    updateImportButtonState();

    setMembershipStatus(
      "Importing membership data…"
    );

    try {
      const response = await fetch(
        `/api/kpi-reports/` +
        `${encodeURIComponent(report.id)}` +
        `/membership-snapshot`,
        {
          method: "POST",
          headers: {
            "Content-Type":
              "application/json"
          },
          body: JSON.stringify({
            version: report.version
          })
        }
      );

      if (!response.ok) {
        const problem =
          await response
            .json()
            .catch(() => null);

        throw new Error(
          problem?.detail ||
          problem?.message ||
          `The server returned ${response.status}.`
        );
      }

      report = await response.json();

      hasUnsavedChanges = false;

      document.getElementById(
        "version-label"
      ).textContent =
        `Version ${report.version}`;

      renderMembershipSnapshot();

      setMembershipStatus(
        `Membership data imported for ` +
        `${formatDate(
          report.membershipSnapshot
            ?.dataAsAt
        )}.`,
        "success"
      );
    } catch (error) {
      setMembershipStatus(
        error.message,
        "error"
      );
    } finally {
      membershipImportInProgress = false;

      updateImportButtonState();
    }
  }
);

loadReport();